import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Activity, Users, Wifi, Server, Network, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

interface ServerData {
  online: boolean;
  ip?: string;
  players?: {
    online: number;
    max: number;
  };
  version?: string;
  motd?: {
    clean: string[];
    html?: string[];
    raw?: string[];
  };
  ping?: number;
  port?: number;
  icon?: string;
  hostname?: string;
  mods?: string[] | { names: string[] };
  plugins?: string[] | { names: string[] };
  eula_blocked?: boolean;
  protocol?: number | { version: number };
  software?: string;
  srv_record?: string;
  debug?: {
    cachetime?: number;
    ping?: boolean;
    query?: boolean;
    srv?: boolean;
    querymismatch?: boolean;
  };
}

interface ServerStatusCardProps {
  data: ServerData | null;
  loading: boolean;
  serverIp: string;
  serverType: "java" | "bedrock";
}

const ServerStatusCard = ({ data, loading, serverIp, serverType }: ServerStatusCardProps) => {
  const { toast } = useToast();
  const [copiedMotd, setCopiedMotd] = useState(false);

  const copyMotd = async () => {
    if (data?.motd) {
      // نسخ النص الخام مع رموز الألوان
      const motdText = data.motd.raw 
        ? data.motd.raw.join("\n")
        : data.motd.clean.join("\n");
      await navigator.clipboard.writeText(motdText);
      setCopiedMotd(true);
      toast({
        title: "تم النسخ!",
        description: "تم نسخ MOTD مع رموز الألوان",
      });
      setTimeout(() => setCopiedMotd(false), 2000);
    }
  };

  if (loading) {
    return (
      <Card className="w-full max-w-2xl bg-gradient-card backdrop-blur-md border-border p-8 animate-pulse">
        <div className="space-y-4">
          <div className="h-8 bg-secondary rounded w-1/3"></div>
          <div className="h-20 bg-secondary rounded"></div>
          <div className="h-4 bg-secondary rounded w-2/3"></div>
        </div>
      </Card>
    );
  }

  if (!data) return null;

  const playerPercentage = data.players
    ? (data.players.online / data.players.max) * 100
    : 0;

  return (
    <Card className="w-full max-w-2xl bg-gradient-card backdrop-blur-md border-border p-8 animate-fade-in">
      <div className="space-y-6">
        {/* Server Status Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            {data.icon && (
              <img 
                src={data.icon} 
                alt="Server icon" 
                className="w-12 h-12 rounded-lg border border-border"
                onError={(e) => e.currentTarget.style.display = 'none'}
              />
            )}
            <div>
              <h2 className="text-2xl font-bold text-foreground">{serverIp}</h2>
              <p className="text-sm text-muted-foreground">
                {serverType === "java" ? "Java Edition" : "Bedrock Edition"}
              </p>
            </div>
          </div>
          <Badge
            variant={data.online ? "default" : "destructive"}
            className={
              data.online
                ? "bg-success text-success-foreground shadow-glow-success px-4 py-1"
                : "bg-destructive text-destructive-foreground shadow-glow-destructive px-4 py-1"
            }
          >
            {data.online ? "Online" : "Offline"}
          </Badge>
        </div>

        {data.online && (
          <>
            {/* MOTD Section */}
            {data.motd && data.motd.clean && (
              <div className="bg-secondary/50 rounded-lg p-4 border border-border">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground mb-2">Message of the Day</p>
                    <div 
                      className="font-minecraft text-base leading-relaxed"
                      style={{ fontFamily: 'monospace' }}
                      dangerouslySetInnerHTML={{ 
                        __html: data.motd.html 
                          ? data.motd.html.join('<br/>') 
                          : data.motd.clean.join('<br/>') 
                      }}
                    />
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={copyMotd}
                    className="shrink-0"
                  >
                    {copiedMotd ? (
                      <Check className="w-4 h-4 text-success" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            )}

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Players */}
              <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="w-5 h-5 text-primary" />
                  <p className="text-sm text-muted-foreground">Players</p>
                </div>
                <p className="text-2xl font-bold text-foreground">
                  {data.players?.online || 0}
                  <span className="text-muted-foreground text-lg">
                    /{data.players?.max || 0}
                  </span>
                </p>
                <Progress value={playerPercentage} className="mt-2" />
              </div>

              {/* Version */}
              <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-5 h-5 text-primary" />
                  <p className="text-sm text-muted-foreground">Version</p>
                </div>
                <p className="text-lg font-bold text-foreground">
                  {data.version || "Unknown"}
                </p>
              </div>

              {/* Port */}
              <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                <div className="flex items-center gap-2 mb-2">
                  <Network className="w-5 h-5 text-primary" />
                  <p className="text-sm text-muted-foreground">Port</p>
                </div>
                <p className="text-2xl font-bold text-foreground">
                  {data.port || (serverType === "bedrock" ? "19132" : "25565")}
                </p>
              </div>

              {/* Ping */}
              {data.ping !== undefined && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <div className="flex items-center gap-2 mb-2">
                    <Wifi className="w-5 h-5 text-primary" />
                    <p className="text-sm text-muted-foreground">Latency</p>
                  </div>
                  <p className="text-2xl font-bold text-foreground">
                    {data.ping}
                    <span className="text-muted-foreground text-lg">ms</span>
                  </p>
                </div>
              )}
            </div>

            {/* Additional Server Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Hostname */}
              {data.hostname && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">Hostname</p>
                  <p className="text-foreground font-medium break-all">{data.hostname}</p>
                </div>
              )}

              {/* IP Address */}
              {data.ip && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">IP Address</p>
                  <p className="text-foreground font-medium">{data.ip}</p>
                </div>
              )}

              {/* Protocol Version */}
              {data.protocol !== undefined && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">Protocol Version</p>
                  <p className="text-foreground font-medium">
                    {typeof data.protocol === 'object' ? data.protocol.version : data.protocol}
                  </p>
                </div>
              )}

              {/* Software */}
              {data.software && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">Software</p>
                  <p className="text-foreground font-medium">{data.software}</p>
                </div>
              )}

              {/* Blocked by Mojang */}
              {data.eula_blocked !== undefined && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">Blocked by Mojang</p>
                  <p className="text-foreground font-medium">
                    {data.eula_blocked ? "Yes" : "No"}
                  </p>
                </div>
              )}

              {/* SRV Record */}
              <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                <p className="text-sm text-muted-foreground mb-1">SRV Record</p>
                <p className="text-foreground font-medium">
                  {data.debug?.srv ? "Yes" : "No"}
                </p>
              </div>

              {/* Ping Status */}
              <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                <p className="text-sm text-muted-foreground mb-1">Ping</p>
                <p className="text-foreground font-medium">
                  {data.debug?.ping ? "Yes" : "No"}
                </p>
              </div>

              {/* Query Status */}
              <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                <p className="text-sm text-muted-foreground mb-1">Query</p>
                <p className="text-foreground font-medium">
                  {data.debug?.query ? "Yes" : "No"}
                </p>
              </div>

              {/* Cache Time */}
              {data.debug?.cachetime && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">Cache Time</p>
                  <p className="text-foreground font-medium text-sm">
                    {new Date(data.debug.cachetime * 1000).toLocaleString()}
                  </p>
                </div>
              )}

              {/* Mods */}
              {data.mods && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">Mods</p>
                  <p className="text-foreground font-medium">
                    {Array.isArray(data.mods) 
                      ? data.mods.length > 0 ? `${data.mods.length} mods` : "N/A"
                      : data.mods.names && data.mods.names.length > 0 
                        ? `${data.mods.names.length} mods` 
                        : "N/A"
                    }
                  </p>
                </div>
              )}

              {/* Plugins */}
              {data.plugins && (
                <div className="bg-secondary/30 rounded-lg p-4 border border-border">
                  <p className="text-sm text-muted-foreground mb-1">Plugins</p>
                  <p className="text-foreground font-medium">
                    {Array.isArray(data.plugins) 
                      ? data.plugins.length > 0 ? `${data.plugins.length} plugins` : "N/A"
                      : data.plugins.names && data.plugins.names.length > 0 
                        ? `${data.plugins.names.length} plugins` 
                        : "N/A"
                    }
                  </p>
                </div>
              )}
            </div>
          </>
        )}

        {!data.online && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">
              The server is currently offline or unreachable
            </p>
          </div>
        )}
      </div>
    </Card>
  );
};

export default ServerStatusCard;
