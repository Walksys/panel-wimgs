import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Loader2, Info } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import ServerStatusCard from "@/components/ServerStatusCard";
import minecraftBg from "@/assets/minecraft-bg.jpg";

const Index = () => {
  const [serverIp, setServerIp] = useState("");
  const [serverType, setServerType] = useState<"java" | "bedrock">("java");
  const [loading, setLoading] = useState(false);
  const [serverData, setServerData] = useState<any>(null);

  const checkServerStatus = async () => {
    if (!serverIp.trim()) {
      toast({
        title: "Invalid Input",
        description: "Please enter a valid server IP address",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setServerData(null);

    try {
      // Try Java edition first
      let response = await fetch(
        `https://api.mcsrvstat.us/2/${encodeURIComponent(serverIp.trim())}`
      );
      
      if (!response.ok) {
        throw new Error("Failed to fetch server status");
      }

      let data = await response.json();
      let detectedType: "java" | "bedrock" = "java";

      // If Java didn't work, try Bedrock
      if (!data.online) {
        response = await fetch(
          `https://api.mcsrvstat.us/bedrock/2/${encodeURIComponent(serverIp.trim())}`
        );
        
        if (response.ok) {
          const bedrockData = await response.json();
          if (bedrockData.online) {
            data = bedrockData;
            detectedType = "bedrock";
          }
        }
      }

      setServerData(data);
      setServerType(detectedType);

      if (!data.online) {
        toast({
          title: "Server Offline",
          description: `${serverIp} is currently offline or unreachable`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Server Found!",
          description: `${serverIp} is online with ${data.players?.online || 0} players (${detectedType === "java" ? "Java Edition" : "Bedrock Edition"})`,
        });
      }
    } catch (error) {
      console.error("Error fetching server status:", error);
      toast({
        title: "Error",
        description: "Failed to fetch server status. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      checkServerStatus();
    }
  };

  return (
    <main className="min-h-screen bg-background relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-20"
        style={{ backgroundImage: `url(${minecraftBg})` }}
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-dark" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-16 flex flex-col items-center min-h-screen">
        <div className="flex-1 flex flex-col items-center justify-center w-full">
        {/* Hero Section */}
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-5xl md:text-7xl font-bold text-foreground mb-4 tracking-tight">
            Welder Hosting
            <span className="text-primary ml-3">Status</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Check the real-time status of any Minecraft server. Enter a server IP to view player count, version, and more.
          </p>
        </div>

        {/* Search Section */}
        <div className="w-full max-w-2xl mb-8 animate-slide-up">
          {/* Info Notice */}
          <div className="mb-4 bg-card/50 backdrop-blur-sm border border-border rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Info className="w-5 h-5 text-primary shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                Minecraft Java (1.7+), Minecraft Bedrock or servers with enable-query=true are supported.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              type="text"
              placeholder="Enter server IP (e.g., mc.hypixel.net)"
              value={serverIp}
              onChange={(e) => setServerIp(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1 h-12 bg-card/80 backdrop-blur-sm border-border text-foreground placeholder:text-muted-foreground focus:ring-primary"
              disabled={loading}
            />
            <Button
              onClick={checkServerStatus}
              disabled={loading}
              className="h-12 px-8 bg-primary hover:bg-primary/90 text-primary-foreground shadow-glow-primary"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Checking...
                </>
              ) : (
                <>
                  <Search className="w-5 h-5 mr-2" />
                  Check Status
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Results Section */}
        <ServerStatusCard
          data={serverData}
          loading={loading}
          serverIp={serverIp}
          serverType={serverType}
        />
        </div>

        {/* Footer */}
        <footer className="w-full py-8 mt-auto border-t border-border/30">
          <div className="text-center space-y-6 text-sm text-muted-foreground animate-fade-in">
            <p>Try popular servers: mc.hypixel.net • play.hivemc.com • mineplex.com</p>
            
            <p>
              Discord Server{" "}
              <a 
                href="https://discord.gg/shAc2gRnUX" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary hover:underline"
              >
                https://discord.gg/shAc2gRnUX
              </a>
            </p>
            
            <p className="text-xs">Copyright © 2020-2025 Welder Hosting</p>
          </div>
        </footer>
      </div>
    </main>
  );
};

export default Index;
